/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Brocard
 */
public class rectangle {

    public static void main(String[] args) {
    double length = 5.5;
    double width = 4.0;
    double area = length * width;
    double perimeter = 2 * (length + width);

    System.out.printf ("The area of the rectangle is %f.\n", area);
    System.out.printf ("The perimeter of the rectangle is %f.\n", perimeter);
    }
    
}
