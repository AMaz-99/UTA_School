/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Brocard
 */
public class square 
{

    public static void main(String[] args) 
    {
        double side_length = 10.0;
        double square_area = side_length * side_length;
        System.out.println(square_area);
    }
    
}
