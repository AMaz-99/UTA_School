# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 17:45:33 2020

@author: Aamir Mazumdar 1001523593
"""
#Created by Aamir Mazumdar


import numpy as np
import soundfile as sf


SAMPLE_RATE = 8000


def calc_freq(a):
    x = a - 49
    x = x/12
    result = 440 * np.power(2, x)
    return result

def transform_array(freq):
    p_freq = calc_freq(freq)
    p_freq = np.repeat(p_freq, SAMPLE_RATE*.5)
    time = np.linspace(0, 12, SAMPLE_RATE//2*len(freq))
    result = np.cos(2 * p_freq * np.pi * time)
    return result

def main():
    freq = np.array([52, 52, 59, 59, 61, 61, 59, 59, 57, 57, 56, 56,
            54, 54, 56, 52, 59, 59, 57, 57, 56, 56, 54, 54])
    y = transform_array(freq)
    sf.write('twinkle.wav', y, SAMPLE_RATE)

if __name__ == '__main__':
    main()


